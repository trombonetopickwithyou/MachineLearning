Machine Learning Capstone Project
Joshua Williams, Scott Watkins, Dong Guo, Lawrence Lewis

MAIN FILE: Network.m
DATASET LINK ("sets" folder with 3 datasets + raw dataset named "Images2.zip"):
https://texastechuniversity-my.sharepoint.com/:u:/g/personal/josh_williams_ttu_edu/EZhUUHK2hdVLjo_lKbdKZ3sBu-8DDuSWGrbUQVQLdo7eqw?e=SsLJip





Supplementary Files:

"MLP5SetDev.m" and "assimilate.m" were used to label all images of worms and create pool of raw data ("Images2.zip" in OneDrive).
"TrainandTestSet.m" was used to create our training and test datasets from large raw dataset "Images2.zip"